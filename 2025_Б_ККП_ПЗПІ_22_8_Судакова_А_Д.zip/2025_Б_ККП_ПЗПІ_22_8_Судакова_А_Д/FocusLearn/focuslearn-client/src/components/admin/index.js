// src/components/AdminPanel/index.js
export { default } from './AdminPanel';