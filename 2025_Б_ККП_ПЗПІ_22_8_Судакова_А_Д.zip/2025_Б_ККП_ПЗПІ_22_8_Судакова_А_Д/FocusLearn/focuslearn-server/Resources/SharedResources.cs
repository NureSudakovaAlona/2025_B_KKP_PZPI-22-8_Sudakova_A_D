﻿namespace FocusLearn.Resources
{
    public class SharedResources
    {
    }
}
