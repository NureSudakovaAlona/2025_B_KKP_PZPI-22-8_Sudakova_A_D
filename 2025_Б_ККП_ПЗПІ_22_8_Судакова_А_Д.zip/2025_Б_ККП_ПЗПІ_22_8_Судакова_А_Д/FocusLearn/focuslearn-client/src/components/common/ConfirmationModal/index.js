// src/components/common/ConfirmationModal/index.js
export { default } from './ConfirmationModal';