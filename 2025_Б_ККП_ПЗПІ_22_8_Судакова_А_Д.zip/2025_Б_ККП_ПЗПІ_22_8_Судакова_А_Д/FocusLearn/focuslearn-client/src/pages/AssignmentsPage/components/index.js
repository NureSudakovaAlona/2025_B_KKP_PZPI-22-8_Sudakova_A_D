// src/pages/AssignmentsPage/components/index.js
export { default as AssignmentsSidebar } from './AssignmentsSidebar';
export { default as AssignmentsList } from './AssignmentsList';
export { default as MyAssignmentsTabs } from './MyAssignmentsTabs';
export { default as AssignmentDetailsModal } from './AssignmentDetailsModal';