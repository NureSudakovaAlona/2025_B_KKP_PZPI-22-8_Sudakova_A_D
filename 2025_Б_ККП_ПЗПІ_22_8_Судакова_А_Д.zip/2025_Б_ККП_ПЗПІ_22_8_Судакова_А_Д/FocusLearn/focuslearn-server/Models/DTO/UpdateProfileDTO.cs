﻿namespace FocusLearn.Models.DTO
{
    public class UpdateProfileDTO
    {
        public string? UserName { get; set; }
        public string? ProfilePhoto { get; set; }
        public string? Language { get; set; }
    }
}
